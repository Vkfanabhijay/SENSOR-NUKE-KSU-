# Sensor Nuke — Troubleshooting Guide

## Quick Diagnostic Commands

Run these first to understand the current state:

```bash
# 1. Module status
su -c '/data/adb/modules/sensor-nuke/sensor_status.sh'

# 2. Full verification
su -c '/data/adb/modules/sensor-nuke/verify_sensors.sh'

# 3. Check logs
cat /data/local/tmp/sensor-nuke-post-fs-data.log
cat /data/local/tmp/sensor-nuke-service.log

# 4. Module installation
ls -la /data/adb/modules/sensor-nuke/
cat /data/adb/modules/sensor-nuke/module.prop

# 5. KernelSU version
ksud --version
```

---

## Issue Categories

### 1. Sensors Not Disabled After Reboot

**Symptoms:** Proximity/ALS still work after reboot

**Diagnosis:**
```bash
# Check if post-fs-data ran
cat /data/local/tmp/sensor-nuke-post-fs-data.log

# Check if sensors found
grep "FOUND\|Identified" /data/local/tmp/sensor-nuke-post-fs-data.log

# Check current enable values
su -c 'cat /sys/bus/iio/devices/iio:device*/enable 2>/dev/null'
su -c 'cat /sys/bus/iio/devices/iio:device*/buffer/enable 2>/dev/null'
```

**Solutions:**

| Cause | Fix |
|-------|-----|
| Module not loaded | Check KernelSU app → Modules → Sensor Nuke shows "Installed" |
| Wrong sensor patterns | Run `su -c 'cat /sys/bus/iio/devices/iio:device*/name'` and update `config.sh` |
| Sensors at different paths | Check `verify_sensors.sh` output for "NOT FOUND" paths, add to `SYSFS_SENSORS` in config |
| post-fs-data failed | Run manually: `su -c '/data/adb/modules/sensor-nuke/post-fs-data.sh'` |
| SELinux blocking | Check `dmesg | grep -i sensor-nuke` or `dmesg | grep avc` |

**Manual re-disable:**
```bash
su -c '/data/adb/modules/sensor-nuke/post-fs-data.sh'
su -c '/data/adb/modules/sensor-nuke/service.sh &'
```

---

### 2. Sensors Re-enable After Framework Restart

**Symptoms:** Work after boot, but re-enable after `systemctl restart sensorservice` or similar

**Diagnosis:**
```bash
# Check service monitor
cat /data/adb/sensor-nuke/persist.conf

# Check tracked PIDs
cat /data/adb/sensor-nuke/sensorservice.pid
pidof sensorservice

# Check monitor running
cat /data/adb/sensor-nuke/monitor.pid
ps | grep sensor-nuke
```

**Solutions:**

| Cause | Fix |
|-------|-----|
| Service monitor not running | `su -c '/data/adb/modules/sensor-nuke/service.sh &'` |
| PID tracking failed | Increase `PERSIST_CHECK_INTERVAL` in config.sh (default 300s) |
| Vendor service not monitored | Add to `MONITOR_VENDOR_SERVICES=1` and check service names |
| Framework bypasses sysfs | Some HALs cache sensor state — may need kernel driver parameter |

**Force re-enforce:**
```bash
su -c '/data/adb/modules/sensor-nuke/post-fs-data.sh'
```

---

### 3. Other Sensors Disabled (False Positives)

**Symptoms:** Accelerometer, gyroscope, or other sensors stop working

**Diagnosis:**
```bash
# Run verification - look for "Other sensor disabled" warnings
su -c '/data/adb/modules/sensor-nuke/verify_sensors.sh' 2>&1 | grep -i "other sensor"

# Check what patterns matched
su -c 'cat /sys/bus/iio/devices/iio:device*/name' | tr '[:upper:]' '[:lower:]'
```

**Solutions:**

| Cause | Fix |
|-------|-----|
| Pattern too broad | Make `PROXIMITY_PATTERNS`/`ALS_PATTERNS` more specific in config.sh |
| Sensor name contains "light" or "proximity" | Add to `SENSOR_WHITELIST` in config.sh |
| Combined sensor (prox+ALS in one) | Use `STRICT_MATCHING=1` and/or specific driver name |

**Example fix for combined sensor (LTR553):**
```bash
# In config.sh:
PROXIMITY_PATTERNS="ltr553_prox"
ALS_PATTERNS="ltr553_als"
STRICT_MATCHING=1
```

**Whitelist example:**
```bash
# In config.sh:
SENSOR_WHITELIST="accel gyro magnetometer hall fingerprint"
```

---

### 4. Module Not Loading / Not in KernelSU App

**Symptoms:** Module installed but not shown in app, or shows "Not installed"

**Diagnosis:**
```bash
# Check module directory
ls -la /data/adb/modules/sensor-nuke/

# Check module.prop
cat /data/adb/modules/sensor-nuke/module.prop

# Check KernelSU module list
ls /data/adb/modules/

# Check KernelSU version
ksud --version
```

**Solutions:**

| Cause | Fix |
|-------|-----|
| module.prop missing/corrupt | Reinstall module |
| Wrong `id` in module.prop | Must be `id=sensor-nuke` |
| KernelSU too old | Requires API 10600+ (v0.6.0+) |
| SELinux context wrong | `su -c 'restorecon -R /data/adb/modules/sensor-nuke'` |
| Scripts not executable | `su -c 'chmod 755 /data/adb/modules/sensor-nuke/*.sh'` |

---

### 5. Bootloop / Device Won't Boot

**Symptoms:** Stuck at boot logo, boot animation loops

**Immediate Recovery:**

1. **Boot to recovery** (Power + Vol Down, or `adb reboot recovery`)
2. **Mount data** (in TWRP: Mount → check Data)
3. **Delete module:**
   ```bash
   adb shell
   rm -rf /data/adb/modules/sensor-nuke
   rm -rf /data/adb/sensor-nuke
   ```
4. **Reboot**

**Root Cause Analysis:**

| Cause | Prevention |
|-------|------------|
| Disabled critical sensor | Module only targets prox/ALS — verify patterns |
| SELinux policy violation | Check `dmesg` before reboot; use permissive for testing |
| Race condition in post-fs-data | Module waits for sysfs — very unlikely |
| Kernel panic from driver | Report with `dmesg` / `last_kmsg` |

**Safe testing:** Use `DRY_RUN=1` in config.sh first — logs what would be done without disabling.

---

### 6. Verification Shows "NOT FOUND" for Target Sensors

**Symptoms:** `verify_sensors.sh` says proximity/ALS not found, but they exist

**Diagnosis:**
```bash
# List ALL IIO devices
su -c 'for d in /sys/bus/iio/devices/iio:device*; do echo "=== $(basename $d) ==="; cat $d/name 2>/dev/null; done'

# List ALL platform sensors
su -c 'find /sys/bus/i2c/devices /sys/bus/spi/devices /sys/class/sensors /sys/class/hwmon /sys/devices/platform /sys/devices/virtual/sensors -name "name" -exec sh -c "echo {}; cat {}" \; 2>/dev/null'

# Check dmesg for sensor drivers
dmesg | grep -iE "proximity|als|ambient|light|sensor" | head -30
```

**Solutions:**

| Cause | Fix |
|-------|-----|
| Different naming | Update `PROXIMITY_PATTERNS`/`ALS_PATTERNS` with actual names |
| Non-IIO sensor | Add path to `SYSFS_SENSORS` in config.sh |
| Sensor hub / composite | Check vendor paths in `VENDOR_SENSOR_PATHS` |
| Driver not loaded | Sensor may need kernel module — check `lsmod` |

**Example: Samsung sensors often at:**
```
/sys/bus/i2c/devices/XX-0040/name  → "stk3x1x"
/sys/bus/i2c/devices/XX-001e/name  → "ap3212"
```

Add to config:
```bash
SYSFS_SENSORS="... /sys/bus/i2c/devices"
PROXIMITY_PATTERNS="proximity|stk3x1x|ap3212"
ALS_PATTERNS="als|ambient|light|stk3x1x|ap3212"
```

---

### 7. Permission Denied / Can't Write Sysfs

**Symptoms:** "Permission denied" in logs when writing enable files

**Diagnosis:**
```bash
# Check file permissions
ls -la /sys/bus/iio/devices/iio:device0/enable
ls -la /sys/bus/iio/devices/iio:device0/buffer/enable

# Check SELinux context
ls -Z /sys/bus/iio/devices/iio:device0/enable

# Check if root
id
```

**Solutions:**

| Cause | Fix |
|-------|-----|
| Not running as root | All scripts must run via `su -c` |
| SELinux enforcing | Check `getenforce`; try `su -c 'setenforce 0'` temporarily |
| Wrong SELinux context | `restorecon -R /sys/bus/iio/devices/iio:device0` |
| File immutable | `lsattr` — rarely set on sysfs |

---

### 8. Logs Show Errors

**Common log messages and meanings:**

| Log Message | Meaning | Action |
|-------------|---------|--------|
| `Enable file: NOT FOUND` | Sensor doesn't have standard enable file | Check vendor paths, add custom path |
| `Failed to disable` | Write to enable file failed | Check permissions, SELinux |
| `Sensor service restarted` | Normal — service monitor working | Verify re-enforce happened |
| `No state file found` | First run or state cleared | Normal on first boot |
| `IIO buffer: ENABLED` | Buffer not disabled | Check `DISABLE_VIA_IIO_BUFFER=1` |

---

## Device-Specific Issues

### Google Pixel (Tensor)

- **Combined sensor:** LTR553 does both prox + ALS
- **Fix:** Use specific driver name, enable `STRICT_MATCHING`
- **Path:** `/sys/bus/iio/devices/iio:deviceX/name` → "ltr553"

### Samsung Galaxy

- **Drivers:** STK3X1X, AP3212, LTR553
- **Paths:** Often under `/sys/bus/i2c/devices/`
- **May need:** Vendor HAL paths in `VENDOR_SENSOR_PATHS`

### OnePlus

- **Drivers:** CM36651, RPR0521
- **Check:** `dmesg | grep -i cm36651`

### Xiaomi

- **Varied:** STK3X1X, LTR553, AP3212, custom
- **Check:** `cat /sys/bus/iio/devices/iio:device*/name`

---

## Debug Mode

Enable maximum logging:

```bash
# Edit config
su -c 'sed -i "s/LOG_LEVEL=.*/LOG_LEVEL=3/" /data/adb/modules/sensor-nuke/config.sh'

# Or create local override
su -c 'echo "LOG_LEVEL=3" >> /data/adb/modules/sensor-nuke/config.sh.local'

# Re-run
su -c '/data/adb/modules/sensor-nuke/post-fs-data.sh'
su -c '/data/adb/modules/sensor-nuke/verify_sensors.sh'
```

---

## Collecting Debug Info for Support

Create a debug package:

```bash
su -c '
mkdir -p /sdcard/sensor-nuke-debug
cd /sdcard/sensor-nuke-debug

# Device info
getprop ro.product.device > device.txt
getprop ro.build.version.release >> device.txt
uname -r >> device.txt
ksud --version >> device.txt

# Module info
cp /data/adb/modules/sensor-nuke/module.prop .
cp /data/adb/modules/sensor-nuke/config.sh .

# Logs
cp /data/local/tmp/sensor-nuke-*.log .

# Verification
/data/adb/modules/sensor-nuke/verify_sensors.sh > verify.txt 2>&1

# Sysfs dump
for d in /sys/bus/iio/devices/iio:device*; do
  echo "=== $(basename $d) ===" >> sysfs.txt
  cat $d/name 2>/dev/null >> sysfs.txt
  cat $d/enable 2>/dev/null >> sysfs.txt
  cat $d/buffer/enable 2>/dev/null >> sysfs.txt
  ls $d/scan_elements/ 2>/dev/null >> sysfs.txt
done

# Platform sensors
find /sys/bus/i2c/devices /sys/bus/spi/devices /sys/class/sensors /sys/class/hwmon -name "name" -exec sh -c "echo {}; cat {}" \; >> platform.txt 2>&1

# dmesg
dmesg | grep -iE "sensor|iio|proximity|als|ambient|light" > dmesg.txt

# Kernel modules
lsmod > lsmod.txt
'

# Pull to host
adb pull /sdcard/sensor-nuke-debug .
```

---

## FAQ

**Q: Does this work on Android 14/15?**
A: Yes, tested on Android 10-15. KernelSU handles version differences.

**Q: Will this break auto-brightness?**
A: Yes, that's the point — ALS disabled = no auto-brightness. Proximity disabled = screen won't turn off during calls.

**Q: Can I disable only one sensor?**
A: Edit config.sh: set unwanted pattern to empty or comment out disable calls in post-fs-data.sh.

**Q: Does this affect fingerprint sensor?**
A: No — fingerprint is separate. Verify with `verify_sensors.sh`.

**Q: Is this permanent?**
A: No — uninstall restores everything. No flash partition modifications.

**Q: Why not just use Android settings?**
A: Settings only toggle HAL registration. This disables at driver level — apps/framework can't re-enable.

**Q: KernelSU vs Magisk?**
A: KernelSU has better early-boot integration (post-fs-data). Magisk not supported.

---

## Still Stuck?

1. Run debug collection (above)
2. Check [GitHub Issues](https://github.com/your-repo/sensor-nuke/issues)
3. Open new issue with:
   - Device model + codename
   - Android version
   - KernelSU version
   - Debug zip attached
   - What you expected vs what happened