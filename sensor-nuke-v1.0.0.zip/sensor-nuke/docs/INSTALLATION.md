# Sensor Nuke — Installation Guide

## Prerequisites

Before installing, ensure you have:

- [ ] **KernelSU installed and working** (v0.6.0+ / API 10600+)
- [ ] **Root access** via KernelSU
- [ ] **Android 10+** (API 29+)
- [ ] **Bootloader unlocked** (required for KernelSU)
- [ ] **Backup** of important data (standard precaution)

### Verify KernelSU Installation

```bash
adb shell
su
ksud --version
# Should output version ≥ 0.6.0

# Or check via KernelSU app
# App shows "KernelSU v0.x.x" on main screen
```

**⚠️ Magisk is NOT supported.** This module uses KernelSU-specific APIs and boot stages.

## Download

### Option 1: Pre-built Release (Recommended)

1. Go to [Releases](https://github.com/your-repo/sensor-nuke/releases)
2. Download `sensor-nuke-v1.0.0.zip`
3. Verify checksum:
   ```bash
   sha256sum sensor-nuke-v1.0.0.zip
   # Compare with release page
   ```

### Option 2: Build from Source

```bash
git clone https://github.com/your-repo/sensor-nuke.git
cd sensor-nuke
./build.sh  # Creates sensor-nuke.zip in release/
```

## Installation Methods

### Method 1: KernelSU App (Easiest)

1. **Transfer zip to device**
   ```bash
   adb push sensor-nuke-v1.0.0.zip /sdcard/Download/
   ```

2. **Open KernelSU App**
   - Tap "Modules" tab
   - Tap "Install from zip" (or + button → Install from zip)
   - Navigate to `/sdcard/Download/sensor-nuke-v1.0.0.zip`
   - Select and confirm

3. **Reboot**
   - KernelSU app will prompt to reboot
   - Or manually: `adb reboot`

4. **Verify**
   - Open KernelSU app → Modules → Sensor Nuke should show "Installed"
   - Run verification (see below)

### Method 2: ADB + Root Shell (Manual)

```bash
# 1. Push module files to device
adb push sensor-nuke /sdcard/sensor-nuke

# 2. Enter root shell
adb shell
su

# 3. Run installer
cd /sdcard/sensor-nuke/scripts
./install.sh

# 4. Reboot
reboot
```

Expected installer output:
```
===========================================
  Sensor Nuke - Installation Script
===========================================

[OK] Running as root
[OK] KernelSU detected (version: 10603)
[OK] Copied module.prop
[OK] Copied post-fs-data.sh
[OK] Copied service.sh
[OK] Copied uninstall.sh
[OK] Copied config.sh
[OK] Copied verify_sensors.sh
[OK] Copied sensor_status.sh
[OK] SELinux contexts restored
[OK] Module marker created
[OK] module.prop present
[OK] post-fs-data.sh executable
[OK] service.sh executable
[OK] uninstall.sh executable
[OK] verify_sensors.sh executable
[OK] sensor_status.sh executable
[OK] Initial disable completed

===========================================
  Installation Complete!
===========================================
```

### Method 3: Custom Recovery (TWRP/OFOX)

1. Boot to recovery
2. Install → Select `sensor-nuke-v1.0.0.zip`
3. Swipe to confirm flash
4. Reboot system

## Post-Installation Verification

### Immediate Check (After Reboot)

```bash
adb shell
su
/data/adb/modules/sensor-nuke/sensor_status.sh
```

Expected:
```
Sensor Nuke Status
==================

Proximity: DISABLED
ALS:       DISABLED
Service:   RUNNING
```

### Comprehensive Verification

```bash
su -c '/data/adb/modules/sensor-nuke/verify_sensors.sh'
```

This checks:
- IIO subsystem sensors
- Platform sensors (I2C, SPI, hwmon)
- Vendor-specific paths
- Android Sensor HAL
- Module state files
- Service monitor status
- Direct sensor data reads (requires root)

### Test Sensor Apps

Install a sensor test app (e.g., "Sensor Test", "CPU-Z", "AIDA64") and verify:
- [ ] **Proximity** — Shows "Unavailable" or "No data" or 0.0 / 5.0 (fixed)
- [ ] **Light/ALS** — Shows "Unavailable" or 0 lux
- [ ] **Accelerometer** — Works normally (rotate screen test)
- [ ] **Gyroscope** — Works normally
- [ ] **Magnetometer** — Works (compass apps)
- [ ] **Fingerprint** — Works (enroll/unlock)
- [ ] **Hall** — Works (flip cover test)

## Configuration (Optional)

If sensors not detected or wrong sensors disabled:

```bash
# Edit config
su -c 'vi /data/adb/modules/sensor-nuke/config.sh'

# Or create local override (preserved on update)
su -c 'cp /data/adb/modules/sensor-nuke/config.sh /data/adb/modules/sensor-nuke/config.sh.local'
su -c 'vi /data/adb/modules/sensor-nuke/config.sh.local'
```

### Common Config Adjustments

**Add device-specific sensor names:**
```bash
# Find your sensor names first:
su -c 'cat /sys/bus/iio/devices/iio:device*/name'

# Then update patterns:
PROXIMITY_PATTERNS="proximity|your_sensor_name"
ALS_PATTERNS="als|ambient|your_als_name"
```

**Add custom sysfs paths:**
```bash
SYSFS_SENSORS="/sys/bus/i2c/devices /sys/bus/spi/devices /sys/class/sensors /sys/class/hwmon /sys/devices/platform /sys/devices/virtual/sensors /sys/devices/soc0 /sys/devices/platform/soc /your/custom/path"
```

**Enable debug logging:**
```bash
LOG_LEVEL=3
```

After config changes, re-run disable:
```bash
su -c '/data/adb/modules/sensor-nuke/post-fs-data.sh'
su -c '/data/adb/modules/sensor-nuke/service.sh &'
```

## Troubleshooting Installation

### "KernelSU not detected"

- Ensure KernelSU is properly installed (not just the app, but the kernel module)
- Check `ls /data/adb/ksu/` exists
- Reinstall KernelSU if needed

### "Permission denied" on scripts

```bash
su -c 'chmod 755 /data/adb/modules/sensor-nuke/*.sh'
```

### Module not showing in KernelSU app

- Check `/data/adb/modules/sensor-nuke/module.prop` exists
- Verify `id=sensor-nuke` in module.prop
- Reboot and check again

### Bootloop after install

1. Boot to recovery
2. `adb shell` → `rm -rf /data/adb/modules/sensor-nuke`
3. Reboot
3. Report issue with device details

## Updating

### Via KernelSU App

1. Download new zip
2. KernelSU app → Modules → Sensor Nuke → Update
3. Select new zip
4. Reboot

### Manual Update

```bash
# Backup config first
adb shell su -c 'cp /data/adb/modules/sensor-nuke/config.sh /sdcard/sensor-nuke-config.backup'

# Install new version (same as fresh install)
# Then restore config
adb shell su -c 'cp /sdcard/sensor-nuke-config.backup /data/adb/modules/sensor-nuke/config.sh'
```

**Note:** `config.sh.local` is preserved automatically.

## Device-Specific Notes

### Google Pixel (Tensor G2/G3)
- Sensors: LTR553 (prox+ALS combined)
- Patterns: `ltr553` covers both
- May need `STRICT_MATCHING=1` in config

### Samsung Galaxy S23/S24
- Sensors: STK3X1X or AP3212
- Check `/sys/bus/iio/devices/iio:device*/name`
- May need vendor paths in `VENDOR_SENSOR_PATHS`

### OnePlus 11/12
- Sensors: CM36651 or RPR0521
- Often at `/sys/bus/i2c/devices/`

### Xiaomi 13/14
- Sensors: Various (STK3X1X, LTR553, AP3212)
- Check `dmesg | grep -i sensor` for driver names

## Support

If installation fails:

1. Collect logs:
   ```bash
   su -c 'cat /data/local/tmp/sensor-nuke-*.log' > sensor-nuke-logs.txt
   ```

2. Collect device info:
   ```bash
   su -c 'getprop ro.product.device; getprop ro.build.version.release; uname -r; ksud --version' > device-info.txt
   ```

3. Run verification and save output:
   ```bash
   su -c '/data/adb/modules/sensor-nuke/verify_sensors.sh' > verify-output.txt
   ```

4. Open issue with all three files attached