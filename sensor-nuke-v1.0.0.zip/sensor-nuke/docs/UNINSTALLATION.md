# Sensor Nuke — Uninstallation Guide

## Quick Uninstall

### Via KernelSU App (Recommended)

1. Open **KernelSU App** → **Modules** tab
2. Find **Sensor Nuke** in the list
3. Tap **Uninstall** (trash icon or menu → Uninstall)
4. **Reboot** when prompted

The app runs `uninstall.sh` automatically, which:
- Restores original sensor enable values
- Re-enables IIO buffers and scan elements
- Restores power management settings
- Cleans up all state files
- Removes module directory

### Via ADB/Root Shell

```bash
adb shell
su
/data/adb/modules/sensor-nuke/uninstall.sh
reboot
```

### Via Recovery

1. Boot to recovery (TWRP/OFOX)
2. File manager → Navigate to `/data/adb/modules/`
3. Delete `sensor-nuke` folder
4. Reboot

## What Uninstall Does

The `uninstall.sh` script performs:

```
1. Stops monitor service (if running)
2. Reads saved state from /data/adb/sensor-nuke/sensor_state.conf
3. For each sensor disabled:
   - Restores original enable file value (0 → 1 typically)
   - Re-enables IIO buffer (buffer/enable = 1)
   - Re-enables all IIO scan elements (*_en = 1)
   - Restores power/control to original (or 'on')
4. Falls back to re-enabling common sensor paths
5. Deletes /data/adb/sensor-nuke/ state directory
6. Module directory removed by KernelSU
```

## Verification After Uninstall

```bash
# Check sensors are restored
su -c '/data/adb/modules/sensor-nuke/verify_sensors.sh'
# (Run before module directory is deleted)

# Or quick check
su -c 'cat /sys/bus/iio/devices/iio:device*/name' | while read name; do
  echo "=== $name ==="
  cat /sys/bus/iio/devices/iio:device*/enable 2>/dev/null
  cat /sys/bus/iio/devices/iio:device*/buffer/enable 2>/dev/null
done
```

Expected: Proximity and ALS sensors show `enable=1` and `buffer/enable=1`

## Manual Restoration (If Uninstall Fails)

If `uninstall.sh` doesn't run or fails:

### 1. Restore from State File

```bash
su
STATE_FILE="/data/adb/sensor-nuke/sensor_state.conf"

if [ -f "$STATE_FILE" ]; then
  # Restore each ORIGINAL_* entry
  grep "^ORIGINAL_" "$STATE_FILE" | while IFS= read -r line; do
    var=$(echo "$line" | cut -d= -f1)
    val=$(echo "$line" | cut -d= -f2-)
    # var format: ORIGINAL_TYPE_PATH=value
    type_path=$(echo "$var" | sed 's/^ORIGINAL_//')
    sensor_type=$(echo "$type_path" | cut -d_ -f1)
    path_part=$(echo "$type_path" | cut -d_ -f2-)
    device_path="/$(echo "$path_part" | sed 's/_/\//g')"
    
    if echo "$device_path" | grep -q "iio:device"; then
      enable_file="$device_path/buffer/enable"
    else
      enable_file="$device_path/enable"
    fi
    
    echo "Restoring $sensor_type at $device_path to $val"
    echo "$val" > "$enable_file" 2>/dev/null
  done
  
  # Re-enable IIO scan elements
  for dev in /sys/bus/iio/devices/iio:device*; do
    for scan_en in "$dev/scan_elements"/*_en; do
      [ -f "$scan_en" ] && echo 1 > "$scan_en" 2>/dev/null
    done
  done
  
  echo "Restoration complete"
else
  echo "No state file found"
fi
```

### 2. Force Re-enable All Proximity/ALS Sensors

```bash
su

# Re-enable via IIO
for dev in /sys/bus/iio/devices/iio:device*; do
  name=$(cat "$dev/name" 2>/dev/null | tr '[:upper:]' '[:lower:]')
  if echo "$name" | grep -qiE "proximity|als|ambient|light"; then
    echo "Re-enabling $name"
    echo 1 > "$dev/enable" 2>/dev/null
    echo 1 > "$dev/buffer/enable" 2>/dev/null
    for scan_en in "$dev/scan_elements"/*_en; do
      [ -f "$scan_en" ] && echo 1 > "$scan_en" 2>/dev/null
    done
    echo on > "$dev/power/control" 2>/dev/null
  fi
done

# Re-enable via platform
for sysfs in /sys/bus/i2c/devices /sys/bus/spi/devices /sys/class/sensors /sys/class/hwmon /sys/devices/platform /sys/devices/virtual/sensors; do
  for dev in "$sysfs"/*; do
    [ -d "$dev" ] || continue
    name=$(cat "$dev/name" 2>/dev/null | tr '[:upper:]' '[:lower:]')
    if echo "$name" | grep -qiE "proximity|als|ambient|light"; then
      echo "Re-enabling platform $name"
      echo 1 > "$dev/enable" 2>/dev/null
      echo on > "$dev/power/control" 2>/dev/null
    fi
  done
done

# Re-enable vendor paths
for f in /sys/devices/virtual/sensors/proximity_sensor/enable /sys/devices/virtual/sensors/light_sensor/enable /sys/class/sensors/proximity_sensor/enable /sys/class/sensors/light_sensor/enable; do
  [ -f "$f" ] && echo 1 > "$f" 2>/dev/null
done

echo "Force re-enable complete"
```

### 3. Clean Up State

```bash
su
rm -rf /data/adb/sensor-nuke
# Then remove module via KernelSU app or:
rm -rf /data/adb/modules/sensor-nuke
reboot
```

## Post-Uninstall Checklist

- [ ] Proximity sensor works (screen turns off during call)
- [ ] Ambient light sensor works (auto-brightness functions)
- [ ] Accelerometer works (screen rotation)
- [ ] Gyroscope works
- [ ] Magnetometer works (compass)
- [ ] Fingerprint works
- [ ] Hall sensor works (flip cover)
- [ ] No sensor-nuke logs in `/data/local/tmp/`
- [ ] Module not listed in KernelSU app

## Common Issues

### "Sensors still disabled after uninstall"

1. Run verification to confirm which sensors affected
2. Use manual restoration commands above
3. Reboot after restoration
4. Check for other modules affecting sensors

### "State file missing"

If `/data/adb/sensor-nuke/sensor_state.conf` is gone:
- Use **Force Re-enable** method above
- It blindly re-enables all proximity/ALS sensors found

### "Module won't uninstall from KernelSU app"

```bash
# Force remove
su
rm -rf /data/adb/modules/sensor-nuke
# Then reboot
reboot
```

### "Bootloop after uninstall"

**Extremely unlikely** — module only modifies runtime sysfs.

If it happens:
1. Boot to recovery
2. `rm -rf /data/adb/modules/sensor-nuke /data/adb/sensor-nuke`
3. Reboot

## Reinstalling

After uninstall, you can reinstall anytime:

1. Download latest zip
2. Install via KernelSU app
3. Reboot
4. Verify

**Previous config is not preserved** — reconfigure if needed.

## Support

If uninstall fails to restore sensors:

1. Run manual restoration commands above
2. Collect logs:
   ```bash
   su -c 'cat /data/local/tmp/sensor-nuke-uninstall.log' > uninstall-log.txt
   ```
3. Run verification and save output
4. Open issue with device details and logs