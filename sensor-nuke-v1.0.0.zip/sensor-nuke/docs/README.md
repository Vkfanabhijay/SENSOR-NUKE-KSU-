# Sensor Nuke — KernelSU Module

A production-quality KernelSU module that completely and persistently disables the **Proximity Sensor** and **Ambient Light Sensor (ALS)** on Android devices while preserving all other sensors.

## Features

- ✅ **Complete disable** — Sensors are disabled at kernel/driver level, not just unregistered from Android
- ✅ **Persistent** — Survives reboots, cold boots, framework restarts, and sensor service restarts
- ✅ **Selective** — Only affects proximity and ALS; accelerometer, gyroscope, magnetometer, fingerprint, hall sensor, and all other sensors remain fully functional
- ✅ **Reversible** — Original sensor state is saved and restored on uninstall
- ✅ **Safe** — No device tree modifications, no shared power rail interference, no calibration data changes
- ✅ **Verifiable** — Comprehensive verification utility included
- ✅ **Configurable** — Device-specific patterns and paths via `config.sh`

## Requirements

- **KernelSU** (v0.6.0+ / API 10600+)
- **Root access** (via KernelSU)
- Android 10+ (API 29+)
- **Not compatible with Magisk** — KernelSU only

## Installation

### Method 1: KernelSU App (Recommended)

1. Download the latest `sensor-nuke.zip` from releases
2. Open KernelSU app → Modules → Install from zip
3. Select the zip file
4. Reboot device

### Method 2: Manual Installation (ADB/Root)

```bash
# Push module to device
adb push sensor-nuke /sdcard/sensor-nuke

# Install via root shell
adb shell
su
cd /sdcard/sensor-nuke/scripts
./install.sh

# Reboot
reboot
```

### Method 3: Recovery Flash

Flash the zip via custom recovery (TWRP, etc.)

## Verification

After installation and reboot:

```bash
# Full verification
su -c '/data/adb/modules/sensor-nuke/verify_sensors.sh'

# Quick status
su -c '/data/adb/modules/sensor-nuke/sensor_status.sh'

# JSON output for scripting
su -c '/data/adb/modules/sensor-nuke/sensor_status.sh --json'
```

Expected output:
```
Proximity: DISABLED
ALS:       DISABLED
Service:   RUNNING
```

## How It Works

### Disable Mechanisms (Priority Order)

1. **IIO Buffer Disable** — Writes `0` to `/sys/bus/iio/devices/iio:deviceX/buffer/enable`
2. **IIO Scan Elements** — Disables all `_en` scan elements in `/sys/bus/iio/devices/iio:deviceX/scan_elements/`
3. **Driver Enable File** — Writes `0` to device `enable` file (platform, i2c, spi, hwmon)
4. **Runtime PM** — Requests suspend via `/sys/.../power/level` and sets `power/control=auto`
5. **Vendor Paths** — Checks common vendor-specific paths (`/sys/class/sensors/`, `/sys/devices/virtual/sensors/`)

### Persistence Strategy

- **post-fs-data.sh** — Runs early boot (before Android framework), disables sensors at driver level
- **service.sh** — Runs late_start, monitors sensor service restarts, re-enforces disable every 5 minutes
- **State tracking** — Saves original enable values for clean restoration
- **Service monitoring** — Tracks `sensorservice`, `sensorhubservice`, vendor sensor HAL PIDs

### Sensor Identification

Sensors identified by **name patterns** (configurable in `config.sh`):

```
Proximity:  proximity, prox, ltr553, stk3x1x, ap3212, cm36651, rpr0521
ALS:        als, ambient, light, ambient_light, light_sensor, ltr553, stk3x1x, ap3212, cm36651, rpr0521
```

**Never assumes fixed sensor IDs or sysfs paths** — dynamically discovers at runtime.

## Configuration

Edit `/data/adb/modules/sensor-nuke/config.sh` (or create `config.sh.local`) to customize:

```bash
# Sensor name patterns (regex, case-insensitive)
PROXIMITY_PATTERNS="proximity|prox|ltr553"
ALS_PATTERNS="als|ambient|light|ltr553"

# Additional sysfs search paths
SYSFS_SENSORS="/sys/bus/i2c/devices /sys/bus/spi/devices /sys/class/sensors ..."

# Disable methods
DISABLE_VIA_IIO_BUFFER=1
DISABLE_VIA_RUNTIME_PM=1

# Persistence
PERSIST_CHECK_INTERVAL=300
MONITOR_SENSOR_SERVICE=1
```

### Device-Specific Presets

Uncomment relevant section in `config.sh`:

```bash
# Google Pixel (Tensor)
# PROXIMITY_PATTERNS="proximity|ltr553"
# ALS_PATTERNS="als|ambient|light|ltr553"

# Samsung Galaxy
# PROXIMITY_PATTERNS="proximity|stk3x1x|ap3212"
# ALS_PATTERNS="als|ambient|light|stk3x1x|ap3212"

# OnePlus
# PROXIMITY_PATTERNS="proximity|cm36651|rpr0521"
# ALS_PATTERNS="als|ambient|light|cm36651|rpr0521"
```

## Uninstallation

### Via KernelSU App

1. Open KernelSU app → Modules
2. Tap "Uninstall" on Sensor Nuke
3. Reboot

### Manual

```bash
su -c '/data/adb/modules/sensor-nuke/uninstall.sh'
# Then remove module directory or use KernelSU app
reboot
```

**Uninstall restores original sensor states** from saved configuration.

## Troubleshooting

### Sensors not disabled after reboot

```bash
# Check logs
cat /data/local/tmp/sensor-nuke-post-fs-data.log
cat /data/local/tmp/sensor-nuke-service.log

# Run manually
su -c '/data/adb/modules/sensor-nuke/post-fs-data.sh'
su -c '/data/adb/modules/sensor-nuke/service.sh &'
```

### Sensors re-enable after framework restart

- Service monitors `sensorservice` PID changes
- Check `/data/adb/sensor-nuke/persist.conf` for last enforcement time
- Increase `PERSIST_CHECK_INTERVAL` in config.sh if needed

### Other sensors affected

- Check `verify_sensors.sh` output for "Other sensor disabled" warnings
- Adjust `PROXIMITY_PATTERNS` / `ALS_PATTERNS` in config.sh to be more specific
- Add sensor names to `SENSOR_WHITELIST` in config.sh

### Module not loading

- Verify KernelSU version ≥ 10600
- Check `/data/adb/modules/sensor-nuke/module.prop` exists
- Ensure scripts are executable (`chmod 755 *.sh`)
- Check SELinux denials: `dmesg | grep -i sensor-nuke`

### Bootloop / Device won't boot

1. Boot to recovery
2. Delete `/data/adb/modules/sensor-nuke`
3. Reboot

**No permanent changes** — module only modifies runtime sysfs values.

## Verification Checklist

After installation, verify:

- [ ] Proximity sensor returns no data / not listed in sensor apps
- [ ] Ambient light sensor returns no data / screen brightness auto-adjust disabled
- [ ] Accelerometer works (rotate screen, shake detection)
- [ ] Gyroscope works (compass, AR apps)
- [ ] Magnetometer works (compass)
- [ ] Fingerprint sensor works
- [ ] Hall sensor works (flip cover detection)
- [ ] State persists after reboot
- [ ] State persists after `systemctl restart sensorservice` (if applicable)
- [ ] Uninstall restores both sensors

## Technical Details

### Files Structure

```
sensor-nuke/
├── module.prop          # KernelSU module metadata
├── post-fs-data.sh      # Early boot disable (pre-framework)
├── service.sh           # Late boot service + persistence monitor
├── uninstall.sh         # Cleanup + state restoration
├── config.sh            # Configuration (patterns, paths, methods)
├── verify_sensors.sh    # Comprehensive verification utility
├── sensor_status.sh     # Quick status command (JSON support)
└── scripts/
    └── install.sh       # Installation helper
```

### State Files

```
/data/adb/sensor-nuke/
├── sensor_state.conf    # Original enable values for restoration
├── persist.conf         # Last enforcement status
├── monitor.pid          # Service monitor PID
├── sensorservice.pid    # Tracked sensor service PIDs
└── *.pid                # Vendor service PIDs
```

### Logs

```
/data/local/tmp/
├── sensor-nuke-post-fs-data.log
├── sensor-nuke-service.log
├── sensor-nuke-uninstall.log
└── sensor-nuke-verify.log
```

## Safety Guarantees

| Check | Implementation |
|-------|----------------|
| No sensor hub disable | Only targets individual sensor devices |
| No shared power rail | Uses per-device enable/runtime PM |
| No calibration modification | Read-only access to calibration files |
| No DT/partition writes | Pure runtime sysfs manipulation |
| Reversible | All original values saved, restored on uninstall |
| No background daemons | Monitor runs only when service.sh active |
| Selective | Whitelist support, strict matching option |

## Supported Architectures

- arm64 (primary)
- arm (32-bit)
- x86_64
- x86

## License

MIT License — See LICENSE file

## Contributing

1. Test on your device
2. Add device-specific patterns to `config.sh`
3. Submit PR with device codename and sensor details

## Changelog

### v1.0.0 (2026-11-12)
- Initial release
- Full IIO, platform, hwmon, vendor path support
- Persistent enforcement with service monitoring
- Comprehensive verification utility
- Configurable patterns and methods
- Complete uninstall restoration