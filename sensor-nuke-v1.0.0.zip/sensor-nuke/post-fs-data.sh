#!/system/bin/sh
#
# Sensor Nuke - post-fs-data.sh
# Runs early in boot (post-fs-data stage) to disable sensors before Android framework starts
#

MODDIR="${0%/*}"
LOG_FILE="/data/local/tmp/sensor-nuke-post-fs-data.log"
CONFIG_FILE="$MODDIR/config.sh"
STATE_DIR="/data/adb/sensor-nuke"
STATE_FILE="$STATE_DIR/sensor_state.conf"

# Ensure state directory exists
mkdir -p "$STATE_DIR"

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

log "=== Sensor Nuke post-fs-data.sh started ==="
log "Module directory: $MODDIR"
log "State directory: $STATE_DIR"

# Load configuration if exists
if [ -f "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
    log "Loaded configuration from $CONFIG_FILE"
else
    log "No config.sh found, using defaults"
fi

# Default sensor identification patterns (can be overridden in config.sh)
PROXIMITY_PATTERNS="${PROXIMITY_PATTERNS:-proximity}"
ALS_PATTERNS="${ALS_PATTERNS:-als|ambient.light|light.sensor}"

# Sysfs paths to search (can be overridden in config.sh)
SYSFS_SENSORS="${SYSFS_SENSORS:-/sys/bus/i2c/devices /sys/bus/spi/devices /sys/class/sensors /sys/class/hwmon /sys/devices/platform /sys/devices/virtual/sensors}"
IIO_SYSFS="${IIO_SYSFS:-/sys/bus/iio/devices}"

# Save original state for restoration
save_original_state() {
    local device_path="$1"
    local sensor_type="$2"
    local enable_file="$3"
    local original_value

    if [ -f "$enable_file" ]; then
        original_value=$(cat "$enable_file" 2>/dev/null)
        echo "ORIGINAL_${sensor_type}_${device_path//\//_}=$original_value" >> "$STATE_FILE"
        log "Saved original state for $sensor_type at $device_path: $original_value"
    fi
}

# Disable sensor via sysfs enable file
disable_sensor_sysfs() {
    local device_path="$1"
    local sensor_type="$2"
    local enable_file="$3"

    if [ -f "$enable_file" ]; then
        save_original_state "$device_path" "$sensor_type" "$enable_file"
        echo 0 > "$enable_file" 2>/dev/null
        if [ $? -eq 0 ]; then
            log "Disabled $sensor_type at $device_path via $enable_file"
            echo "DISABLED_${sensor_type}_${device_path//\//_}=1" >> "$STATE_FILE"
            return 0
        else
            log "Failed to disable $sensor_type at $device_path via $enable_file"
            return 1
        fi
    fi
    return 1
}

# Disable sensor via power control
disable_sensor_power() {
    local device_path="$1"
    local sensor_type="$2"

    # Try runtime PM control
    local power_control="$device_path/power/control"
    local runtime_status="$device_path/power/runtime_status"

    if [ -f "$power_control" ]; then
        save_original_state "$device_path" "${sensor_type}_POWER" "$power_control"
        echo "auto" > "$power_control" 2>/dev/null
        log "Set power control to auto for $sensor_type at $device_path"
    fi

    # Try to suspend the device
    if [ -f "$runtime_status" ]; then
        local status=$(cat "$runtime_status" 2>/dev/null)
        if [ "$status" = "active" ]; then
            echo "suspend" > "$device_path/power/level" 2>/dev/null
            log "Requested suspend for $sensor_type at $device_path"
        fi
    fi
}

# Disable IIO device
disable_iio_device() {
    local iio_path="$1"
    local name_file="$iio_path/name"
    local enable_file="$iio_path/buffer/enable"
    local scan_elements_dir="$iio_path/scan_elements"

    if [ ! -f "$name_file" ]; then
        return 1
    fi

    local name=$(cat "$name_file" 2>/dev/null | tr '[:upper:]' '[:lower:]')
    log "Found IIO device: $name at $iio_path"

    # Check if it's a proximity sensor
    if echo "$name" | grep -qiE "$PROXIMITY_PATTERNS"; then
        log "Identified proximity sensor: $name"
        disable_sensor_sysfs "$iio_path" "PROXIMITY" "$enable_file"
        disable_sensor_power "$iio_path" "PROXIMITY"

        # Disable all scan elements
        if [ -d "$scan_elements_dir" ]; then
            for scan_file in "$scan_elements_dir"/*_en; do
                [ -f "$scan_file" ] && echo 0 > "$scan_file" 2>/dev/null && log "Disabled scan element: $scan_file"
            done
        fi
        return 0
    fi

    # Check if it's an ALS sensor
    if echo "$name" | grep -qiE "$ALS_PATTERNS"; then
        log "Identified ALS sensor: $name"
        disable_sensor_sysfs "$iio_path" "ALS" "$enable_file"
        disable_sensor_power "$iio_path" "ALS"

        # Disable all scan elements
        if [ -d "$scan_elements_dir" ]; then
            for scan_file in "$scan_elements_dir"/*_en; do
                [ -f "$scan_file" ] && echo 0 > "$scan_file" 2>/dev/null && log "Disabled scan element: $scan_file"
            done
        fi
        return 0
    fi

    return 1
}

# Disable sensor via platform device
disable_platform_sensor() {
    local device_path="$1"
    local name_file="$device_path/name"
    local enable_file="$device_path/enable"
    local power_control="$device_path/power/control"

    if [ ! -f "$name_file" ]; then
        return 1
    fi

    local name=$(cat "$name_file" 2>/dev/null | tr '[:upper:]' '[:lower:]')
    log "Found platform device: $name at $device_path"

    # Check for proximity
    if echo "$name" | grep -qiE "$PROXIMITY_PATTERNS"; then
        log "Identified proximity sensor (platform): $name"
        disable_sensor_sysfs "$device_path" "PROXIMITY" "$enable_file"
        disable_sensor_power "$device_path" "PROXIMITY"
        return 0
    fi

    # Check for ALS
    if echo "$name" | grep -qiE "$ALS_PATTERNS"; then
        log "Identified ALS sensor (platform): $name"
        disable_sensor_sysfs "$device_path" "ALS" "$enable_file"
        disable_sensor_power "$device_path" "ALS"
        return 0
    fi

    return 1
}

# Disable sensor via hwmon
disable_hwmon_sensor() {
    local hwmon_path="$1"
    local name_file="$hwmon_path/name"
    local enable_file="$hwmon_path/enable"

    if [ ! -f "$name_file" ]; then
        return 1
    fi

    local name=$(cat "$name_file" 2>/dev/null | tr '[:upper:]' '[:lower:]')
    log "Found hwmon device: $name at $hwmon_path"

    if echo "$name" | grep -qiE "$PROXIMITY_PATTERNS"; then
        log "Identified proximity sensor (hwmon): $name"
        disable_sensor_sysfs "$hwmon_path" "PROXIMITY" "$enable_file"
        return 0
    fi

    if echo "$name" | grep -qiE "$ALS_PATTERNS"; then
        log "Identified ALS sensor (hwmon): $name"
        disable_sensor_sysfs "$hwmon_path" "ALS" "$enable_file"
        return 0
    fi

    return 1
}

# Main detection and disable logic
main() {
    log "Starting sensor detection and disable process..."

    # Clear previous state file
    > "$STATE_FILE"
    echo "# Sensor Nuke State - $(date)" >> "$STATE_FILE"
    echo "MODULE_VERSION=1.0.0" >> "$STATE_FILE"
    echo "TIMESTAMP=$(date +%s)" >> "$STATE_FILE"

    local proximity_found=0
    local als_found=0

    # 1. Scan IIO devices (most common for sensors)
    log "Scanning IIO devices at $IIO_SYSFS..."
    if [ -d "$IIO_SYSFS" ]; then
        for iio_dev in "$IIO_SYSFS"/iio:device*; do
            [ -d "$iio_dev" ] || continue
            disable_iio_device "$iio_dev" && {
                case "$(cat "$iio_dev/name" 2>/dev/null | tr '[:upper:]' '[:lower:]')" in
                    *proximity*) proximity_found=1 ;;
                    *als*|*ambient*|*light*) als_found=1 ;;
                esac
            }
        done
    fi

    # 2. Scan platform sensors
    log "Scanning platform sensors..."
    for sysfs_path in $SYSFS_SENSORS; do
        [ -d "$sysfs_path" ] || continue
        for device in "$sysfs_path"/*; do
            [ -d "$device" ] || continue
            disable_platform_sensor "$device" && {
                case "$(cat "$device/name" 2>/dev/null | tr '[:upper:]' '[:lower:]')" in
                    *proximity*) proximity_found=1 ;;
                    *als*|*ambient*|*light*) als_found=1 ;;
                esac
            }
        done
    done

    # 3. Scan hwmon devices
    log "Scanning hwmon devices..."
    for hwmon in /sys/class/hwmon/hwmon*; do
        [ -d "$hwmon" ] || continue
        disable_hwmon_sensor "$hwmon" && {
            case "$(cat "$hwmon/name" 2>/dev/null | tr '[:upper:]' '[:lower:]')" in
                *proximity*) proximity_found=1 ;;
                *als*|*ambient*|*light*) als_found=1 ;;
            esac
        done
    done

    # 4. Try vendor-specific paths (common patterns)
    log "Checking vendor-specific sensor paths..."
    VENDOR_PATHS="
        /sys/devices/virtual/sensors/proximity_sensor/enable
        /sys/devices/virtual/sensors/light_sensor/enable
        /sys/class/sensors/proximity_sensor/enable
        /sys/class/sensors/light_sensor/enable
        /sys/bus/i2c/devices/*/enable
        /sys/bus/spi/devices/*/enable
    "
    for path in $VENDOR_PATHS; do
        for enable_file in $path; do
            [ -f "$enable_file" ] || continue
            local device_path=$(dirname "$enable_file")
            local name_file="$device_path/name"
            local name=""
            [ -f "$name_file" ] && name=$(cat "$name_file" 2>/dev/null | tr '[:upper:]' '[:lower:]')

            if echo "$name" | grep -qiE "$PROXIMITY_PATTERNS"; then
                log "Found vendor proximity sensor at $device_path"
                disable_sensor_sysfs "$device_path" "PROXIMITY" "$enable_file"
                proximity_found=1
            elif echo "$name" | grep -qiE "$ALS_PATTERNS"; then
                log "Found vendor ALS sensor at $device_path"
                disable_sensor_sysfs "$device_path" "ALS" "$enable_file"
                als_found=1
            elif [ -z "$name" ]; then
                # Try to guess by path
                if echo "$device_path" | grep -qiE "proximity"; then
                    disable_sensor_sysfs "$device_path" "PROXIMITY" "$enable_file"
                    proximity_found=1
                elif echo "$device_path" | grep -qiE "als|ambient|light"; then
                    disable_sensor_sysfs "$device_path" "ALS" "$enable_file"
                    als_found=1
                fi
            fi
        done
    done

    # Save summary
    echo "PROXIMITY_FOUND=$proximity_found" >> "$STATE_FILE"
    echo "ALS_FOUND=$als_found" >> "$STATE_FILE"
    echo "POST_FS_DATA_COMPLETE=1" >> "$STATE_FILE"

    log "=== Summary ==="
    log "Proximity sensor found and disabled: $([ $proximity_found -eq 1 ] && echo YES || echo NO)"
    log "ALS sensor found and disabled: $([ $als_found -eq 1 ] && echo YES || echo NO)"
    log "State saved to: $STATE_FILE"
    log "=== Sensor Nuke post-fs-data.sh completed ==="
}

main "$@"