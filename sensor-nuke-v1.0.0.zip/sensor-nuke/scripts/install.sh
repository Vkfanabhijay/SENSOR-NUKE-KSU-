#!/system/bin/sh
#
# Sensor Nuke - install.sh
# Installation script for KernelSU module
# Run on device with root: su -c '/path/to/install.sh'
#

MODDIR="${0%/*}"
MODULE_DIR="/data/adb/modules/sensor-nuke"
KERNELSU_DIR="/data/adb/ksu"
MAGISK_DIR="/data/adb/modules"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo -e "${BLUE}===========================================${NC}"
    echo -e "${BLUE}  Sensor Nuke - Installation Script${NC}"
    echo -e "${BLUE}===========================================${NC}"
    echo ""
}

print_pass() { echo -e "${GREEN}[OK]${NC} $1"; }
print_fail() { echo -e "${RED}[FAIL]${NC} $1"; }
print_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_info() { echo -e "${BLUE}[INFO]${NC} $1"; }

check_root() {
    if [ "$(id -u)" != "0" ]; then
        print_fail "This script must run as root"
        print_info "Run: su -c '$0'"
        exit 1
    fi
}

check_kernelSU() {
    if [ ! -d "$KERNELSU_DIR" ]; then
        print_fail "KernelSU not detected at $KERNELSU_DIR"
        print_info "This module requires KernelSU. Magisk is not supported."
        exit 1
    fi

    # Check KernelSU version
    local ksu_version=$(cat "$KERNELSU_DIR/version" 2>/dev/null || echo "unknown")
    print_pass "KernelSU detected (version: $ksu_version)"

    # Check minimum version (10600 = v0.6.0)
    local version_num=$(echo "$ksu_version" | sed 's/[^0-9]//g')
    if [ -n "$version_num" ] && [ "$version_num" -lt 10600 ]; then
        print_warn "KernelSU version may be too old (minimum 10600 required)"
    fi
}

backup_existing() {
    if [ -d "$MODULE_DIR" ]; then
        print_warn "Existing module found at $MODULE_DIR"
        local backup_dir="${MODULE_DIR}.backup.$(date +%s)"
        mv "$MODULE_DIR" "$backup_dir"
        print_info "Backed up to $backup_dir"
    fi
}

install_module() {
    print_info "Installing module to $MODULE_DIR..."

    mkdir -p "$MODULE_DIR"

    # Copy all module files
    local files="
        module.prop
        post-fs-data.sh
        service.sh
        uninstall.sh
        config.sh
        verify_sensors.sh
        sensor_status.sh
    "

    for file in $files; do
        if [ -f "$MODDIR/$file" ]; then
            cp "$MODDIR/$file" "$MODULE_DIR/"
            print_pass "Copied $file"
        else
            print_warn "Source file not found: $MODDIR/$file"
        fi
    done

    # Set permissions
    chmod 755 "$MODULE_DIR"/*.sh
    chmod 644 "$MODULE_DIR"/module.prop "$MODULE_DIR"/config.sh

    # Set SELinux context (if SELinux is enforcing)
    if command -v restorecon >/dev/null 2>&1; then
        restorecon -R "$MODULE_DIR" 2>/dev/null
        print_pass "SELinux contexts restored"
    fi

    # Create module marker for KernelSU
    touch "$MODULE_DIR/update"
    print_pass "Module marker created"
}

verify_installation() {
    print_info "Verifying installation..."

    if [ -f "$MODULE_DIR/module.prop" ]; then
        print_pass "module.prop present"
        cat "$MODULE_DIR/module.prop" | grep -E "^(id|name|version)=" | sed 's/^/  /'
    else
        print_fail "module.prop missing"
        return 1
    fi

    for script in post-fs-data.sh service.sh uninstall.sh verify_sensors.sh sensor_status.sh; do
        if [ -x "$MODULE_DIR/$script" ]; then
            print_pass "$script executable"
        else
            print_fail "$script not executable"
        fi
    done

    return 0
}

run_initial_disable() {
    print_info "Running initial sensor disable (post-fs-data.sh)..."
    cd "$MODULE_DIR"
    ./post-fs-data.sh
    print_pass "Initial disable completed"
}

show_post_install() {
    echo ""
    echo -e "${GREEN}===========================================${NC}"
    echo -e "${GREEN}  Installation Complete!${NC}"
    echo -e "${GREEN}===========================================${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. REBOOT your device to activate the module"
    echo "  2. After reboot, verify sensors are disabled:"
    echo "     su -c '$MODULE_DIR/verify_sensors.sh'"
    echo "  3. Quick status check:"
    echo "     su -c '$MODULE_DIR/sensor_status.sh'"
    echo ""
    echo "Module location: $MODULE_DIR"
    echo "Logs: /data/local/tmp/sensor-nuke-*.log"
    echo ""
    echo "To uninstall:"
    echo "  su -c '$MODULE_DIR/uninstall.sh'"
    echo "  Then remove module from KernelSU app"
    echo ""
}

main() {
    print_header
    check_root
    check_kernelSU
    backup_existing
    install_module
    verify_installation
    run_initial_disable
    show_post_install
}

main "$@"