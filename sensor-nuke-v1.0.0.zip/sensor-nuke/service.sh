#!/system/bin/sh
#
# Sensor Nuke - service.sh
# Runs at late_start service stage to ensure sensors stay disabled
# and handles persistence across framework restarts
#

MODDIR="${0%/*}"
LOG_FILE="/data/local/tmp/sensor-nuke-service.log"
CONFIG_FILE="$MODDIR/config.sh"
STATE_DIR="/data/adb/sensor-nuke"
STATE_FILE="$STATE_DIR/sensor_state.conf"
PERSIST_FILE="$STATE_DIR/persist.conf"
MONITOR_PID_FILE="$STATE_DIR/monitor.pid"

# Ensure state directory exists
mkdir -p "$STATE_DIR"

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

log "=== Sensor Nuke service.sh started ==="
log "Module directory: $MODDIR"

# Load configuration if exists
if [ -f "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
    log "Loaded configuration from $CONFIG_FILE"
fi

# Default sensor identification patterns
PROXIMITY_PATTERNS="${PROXIMITY_PATTERNS:-proximity}"
ALS_PATTERNS="${ALS_PATTERNS:-als|ambient.light|light.sensor}"

# Sysfs paths
SYSFS_SENSORS="${SYSFS_SENSORS:-/sys/bus/i2c/devices /sys/bus/spi/devices /sys/class/sensors /sys/class/hwmon /sys/devices/platform /sys/devices/virtual/sensors}"
IIO_SYSFS="${IIO_SYSFS:-/sys/bus/iio/devices}"

# Kill any existing monitor
if [ -f "$MONITOR_PID_FILE" ]; then
    old_pid=$(cat "$MONITOR_PID_FILE" 2>/dev/null)
    if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
        kill "$old_pid" 2>/dev/null
        log "Killed existing monitor process (PID: $old_pid)"
    fi
fi

# Save monitor PID
echo $$ > "$MONITOR_PID_FILE"

# Check if sensors are still disabled, re-disable if needed
verify_and_enforce() {
    local proximity_ok=1
    local als_ok=1

    # Check IIO devices
    if [ -d "$IIO_SYSFS" ]; then
        for iio_dev in "$IIO_SYSFS"/iio:device*; do
            [ -d "$iio_dev" ] || continue
            local name_file="$iio_dev/name"
            local enable_file="$iio_dev/buffer/enable"
            [ -f "$name_file" ] || continue

            local name=$(cat "$name_file" 2>/dev/null | tr '[:upper:]' '[:lower:]')

            if echo "$name" | grep -qiE "$PROXIMITY_PATTERNS"; then
                if [ -f "$enable_file" ]; then
                    local current=$(cat "$enable_file" 2>/dev/null)
                    if [ "$current" != "0" ]; then
                        log "Proximity sensor ($name) re-enabled, disabling again..."
                        echo 0 > "$enable_file" 2>/dev/null
                        proximity_ok=0
                    fi
                fi
                # Check scan elements
                for scan_en in "$iio_dev/scan_elements"/*_en; do
                    [ -f "$scan_en" ] || continue
                    local current=$(cat "$scan_en" 2>/dev/null)
                    [ "$current" = "0" ] || echo 0 > "$scan_en" 2>/dev/null
                done
            elif echo "$name" | grep -qiE "$ALS_PATTERNS"; then
                if [ -f "$enable_file" ]; then
                    local current=$(cat "$enable_file" 2>/dev/null)
                    if [ "$current" != "0" ]; then
                        log "ALS sensor ($name) re-enabled, disabling again..."
                        echo 0 > "$enable_file" 2>/dev/null
                        als_ok=0
                    fi
                fi
                for scan_en in "$iio_dev/scan_elements"/*_en; do
                    [ -f "$scan_en" ] || continue
                    local current=$(cat "$scan_en" 2>/dev/null)
                    [ "$current" = "0" ] || echo 0 > "$scan_en" 2>/dev/null
                done
            fi
        done
    fi

    # Check platform sensors
    for sysfs_path in $SYSFS_SENSORS; do
        [ -d "$sysfs_path" ] || continue
        for device in "$sysfs_path"/*; do
            [ -d "$device" ] || continue
            local name_file="$device/name"
            local enable_file="$device/enable"
            [ -f "$name_file" ] || continue

            local name=$(cat "$name_file" 2>/dev/null | tr '[:upper:]' '[:lower:]')

            if echo "$name" | grep -qiE "$PROXIMITY_PATTERNS"; then
                if [ -f "$enable_file" ]; then
                    local current=$(cat "$enable_file" 2>/dev/null)
                    if [ "$current" != "0" ]; then
                        log "Platform proximity sensor ($name) re-enabled, disabling again..."
                        echo 0 > "$enable_file" 2>/dev/null
                        proximity_ok=0
                    fi
                fi
            elif echo "$name" | grep -qiE "$ALS_PATTERNS"; then
                if [ -f "$enable_file" ]; then
                    local current=$(cat "$enable_file" 2>/dev/null)
                    if [ "$current" != "0" ]; then
                        log "Platform ALS sensor ($name) re-enabled, disabling again..."
                        echo 0 > "$enable_file" 2>/dev/null
                        als_ok=0
                    fi
                fi
            fi
        done
    done

    # Check vendor paths
    VENDOR_PATHS="
        /sys/devices/virtual/sensors/proximity_sensor/enable
        /sys/devices/virtual/sensors/light_sensor/enable
        /sys/class/sensors/proximity_sensor/enable
        /sys/class/sensors/light_sensor/enable
    "
    for enable_file in $VENDOR_PATHS; do
        [ -f "$enable_file" ] || continue
        local current=$(cat "$enable_file" 2>/dev/null)
        if [ "$current" != "0" ]; then
            local device_path=$(dirname "$enable_file")
            local name_file="$device_path/name"
            local name=""
            [ -f "$name_file" ] && name=$(cat "$name_file" 2>/dev/null | tr '[:upper:]' '[:lower:]')

            if echo "$name" | grep -qiE "$PROXIMITY_PATTERNS" || echo "$device_path" | grep -qiE "proximity"; then
                log "Vendor proximity sensor re-enabled, disabling again..."
                echo 0 > "$enable_file" 2>/dev/null
                proximity_ok=0
            elif echo "$name" | grep -qiE "$ALS_PATTERNS" || echo "$device_path" | grep -qiE "als|ambient|light"; then
                log "Vendor ALS sensor re-enabled, disabling again..."
                echo 0 > "$enable_file" 2>/dev/null
                als_ok=0
            fi
        fi
    done

    # Update persist state
    echo "PROXIMITY_ENFORCED=$([ $proximity_ok -eq 1 ] && echo 1 || echo 0)" > "$PERSIST_FILE"
    echo "ALS_ENFORCED=$([ $als_ok -eq 1 ] && echo 1 || echo 0)" >> "$PERSIST_FILE"
    echo "LAST_CHECK=$(date +%s)" >> "$PERSIST_FILE"

    return 0
}

# Monitor sensor service restarts
monitor_sensor_service() {
    log "Starting sensor service monitor..."

    while true; do
        sleep 30

        # Check if sensorservice restarted (pid changed)
        local current_pid=$(pidof sensorservice 2>/dev/null | awk '{print $1}')
        local last_pid=$(cat "$STATE_DIR/sensorservice.pid" 2>/dev/null)

        if [ -n "$current_pid" ] && [ "$current_pid" != "$last_pid" ]; then
            log "Sensor service restarted (old PID: $last_pid, new PID: $current_pid), re-enforcing sensor disable..."
            echo "$current_pid" > "$STATE_DIR/sensorservice.pid"
            verify_and_enforce
        elif [ -z "$last_pid" ] && [ -n "$current_pid" ]; then
            echo "$current_pid" > "$STATE_DIR/sensorservice.pid"
        fi

        # Also check vendor sensor services
        for svc in "sensorhubservice" "vendor.sensorservice" "android.hardware.sensors@2.0-service"; do
            local svc_pid=$(pidof "$svc" 2>/dev/null | awk '{print $1}')
            local last_svc_pid=$(cat "$STATE_DIR/${svc}.pid" 2>/dev/null)
            if [ -n "$svc_pid" ] && [ "$svc_pid" != "$last_svc_pid" ]; then
                log "Vendor service $svc restarted, re-enforcing..."
                echo "$svc_pid" > "$STATE_DIR/${svc}.pid"
                verify_and_enforce
            elif [ -z "$last_svc_pid" ] && [ -n "$svc_pid" ]; then
                echo "$svc_pid" > "$STATE_DIR/${svc}.pid"
            fi
        done

        # Periodic enforcement (every 5 minutes)
        local last_check=$(cat "$PERSIST_FILE" 2>/dev/null | grep LAST_CHECK | cut -d= -f2)
        local now=$(date +%s)
        if [ -n "$last_check" ] && [ $((now - last_check)) -gt 300 ]; then
            verify_and_enforce
        fi
    done
}

# Handle boot completed - ensure sensors are disabled after full boot
handle_boot_completed() {
    # Wait for boot to complete
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 2
    done

    log "Boot completed, performing final sensor disable enforcement..."
    verify_and_enforce

    # Give framework time to initialize sensors
    sleep 5
    verify_and_enforce
}

# Main service logic
main() {
    log "Starting Sensor Nuke service..."

    # Wait a bit for post-fs-data to complete
    sleep 3

    # Initial enforcement
    verify_and_enforce

    # Handle boot completion in background
    handle_boot_completed &

    # Start monitor loop
    monitor_sensor_service
}

# Trap signals for clean shutdown
trap 'log "Service received signal, shutting down..."; rm -f "$MONITOR_PID_FILE"; exit 0' TERM INT

main "$@"