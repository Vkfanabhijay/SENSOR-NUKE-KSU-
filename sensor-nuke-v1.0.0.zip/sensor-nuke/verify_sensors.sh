#!/system/bin/sh
#
# Sensor Nuke - verify_sensors.sh
# Comprehensive sensor verification utility
# Run on device to verify sensor disable status
#

MODDIR="${0%/*}"
LOG_FILE="/data/local/tmp/sensor-nuke-verify.log"
STATE_DIR="/data/adb/sensor-nuke"
STATE_FILE="$STATE_DIR/sensor_state.conf"
PERSIST_FILE="$STATE_DIR/persist.conf"
CONFIG_FILE="$MODDIR/config.sh"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Load config if available
if [ -f "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
fi

PROXIMITY_PATTERNS="${PROXIMITY_PATTERNS:-proximity|prox}"
ALS_PATTERNS="${ALS_PATTERNS:-als|ambient.light|light.sensor|ambient_light|light_sensor}"
IIO_SYSFS="${IIO_SYSFS:-/sys/bus/iio/devices}"
SYSFS_SENSORS="${SYSFS_SENSORS:-/sys/bus/i2c/devices /sys/bus/spi/devices /sys/class/sensors /sys/class/hwmon /sys/devices/platform /sys/devices/virtual/sensors}"

# Logging
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

print_header() {
    echo -e "${BLUE}===========================================${NC}"
    echo -e "${BLUE}  Sensor Nuke - Verification Utility${NC}"
    echo -e "${BLUE}===========================================${NC}"
    echo ""
}

print_section() {
    echo -e "${YELLOW}--- $1 ---${NC}"
}

print_pass() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

print_fail() {
    echo -e "${RED}[FAIL]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Check if running as root
check_root() {
    if [ "$(id -u)" != "0" ]; then
        print_warn "Not running as root. Some checks may be limited."
        print_info "Run with: su -c '$0'"
        echo ""
    fi
}

# Verify a specific sensor device
verify_sensor_device() {
    local device_path="$1"
    local sensor_type="$2"
    local name="$3"
    local enable_file="$4"

    local issues=0

    print_info "Checking $sensor_type: $name at $device_path"

    # Check enable file
    if [ -f "$enable_file" ]; then
        local current=$(cat "$enable_file" 2>/dev/null)
        if [ "$current" = "0" ]; then
            print_pass "  Enable file: DISABLED (value=0)"
        else
            print_fail "  Enable file: ENABLED (value=$current)"
            issues=$((issues + 1))
        fi
    else
        print_warn "  Enable file: NOT FOUND ($enable_file)"
    fi

    # Check IIO buffer
    if echo "$device_path" | grep -q "/iio:device"; then
        local buffer_enable="$device_path/buffer/enable"
        if [ -f "$buffer_enable" ]; then
            local current=$(cat "$buffer_enable" 2>/dev/null)
            if [ "$current" = "0" ]; then
                print_pass "  IIO buffer: DISABLED"
            else
                print_fail "  IIO buffer: ENABLED (value=$current)"
                issues=$((issues + 1))
            fi
        fi

        # Check scan elements
        local scan_dir="$device_path/scan_elements"
        if [ -d "$scan_dir" ]; then
            local enabled_scans=0
            for scan_en in "$scan_dir"/*_en; do
                [ -f "$scan_en" ] || continue
                local current=$(cat "$scan_en" 2>/dev/null)
                if [ "$current" = "1" ]; then
                    enabled_scans=$((enabled_scans + 1))
                fi
            done
            if [ $enabled_scans -eq 0 ]; then
                print_pass "  IIO scan elements: ALL DISABLED"
            else
                print_fail "  IIO scan elements: $enabled_scans ENABLED"
                issues=$((issues + 1))
            fi
        fi
    fi

    # Check power control
    local power_control="$device_path/power/control"
    if [ -f "$power_control" ]; then
        local current=$(cat "$power_control" 2>/dev/null)
        print_info "  Power control: $current"
    fi

    # Check runtime status
    local runtime_status="$device_path/power/runtime_status"
    if [ -f "$runtime_status" ]; then
        local current=$(cat "$runtime_status" 2>/dev/null)
        print_info "  Runtime status: $current"
    fi

    return $issues
}

# Scan IIO devices
scan_iio_devices() {
    print_section "Scanning IIO Devices ($IIO_SYSFS)"

    if [ ! -d "$IIO_SYSFS" ]; then
        print_warn "IIO sysfs not found at $IIO_SYSFS"
        return
    fi

    local found=0
    for iio_dev in "$IIO_SYSFS"/iio:device*; do
        [ -d "$iio_dev" ] || continue

        local name_file="$iio_dev/name"
        [ -f "$name_file" ] || continue

        local name=$(cat "$name_file" 2>/dev/null)
        local name_lower=$(echo "$name" | tr '[:upper:]' '[:lower:]')

        local is_proximity=0
        local is_als=0
        local is_other=0

        if echo "$name_lower" | grep -qiE "$PROXIMITY_PATTERNS"; then
            is_proximity=1
        elif echo "$name_lower" | grep -qiE "$ALS_PATTERNS"; then
            is_als=1
        else
            is_other=1
        fi

        if [ $is_proximity -eq 1 ] || [ $is_als -eq 1 ]; then
            found=$((found + 1))
            local sensor_type=""
            [ $is_proximity -eq 1 ] && sensor_type="PROXIMITY" || sensor_type="ALS"
            local enable_file="$iio_dev/enable"
            [ -f "$iio_dev/buffer/enable" ] && enable_file="$iio_dev/buffer/enable"

            verify_sensor_device "$iio_dev" "$sensor_type" "$name" "$enable_file"
            echo ""
        elif [ $is_other -eq 1 ]; then
            # Check if other sensors are still enabled (good)
            local enable_file="$iio_dev/enable"
            [ -f "$iio_dev/buffer/enable" ] && enable_file="$iio_dev/buffer/enable"
            if [ -f "$enable_file" ]; then
                local current=$(cat "$enable_file" 2>/dev/null)
                if [ "$current" = "1" ]; then
                    print_pass "Other sensor OK: $name (enabled)"
                else
                    print_warn "Other sensor disabled: $name (value=$current)"
                fi
            fi
        fi
    done

    if [ $found -eq 0 ]; then
        print_warn "No proximity or ALS sensors found in IIO subsystem"
    fi
}

# Scan platform sensors
scan_platform_sensors() {
    print_section "Scanning Platform Sensors"

    local found=0
    for sysfs_path in $SYSFS_SENSORS; do
        [ -d "$sysfs_path" ] || continue

        for device in "$sysfs_path"/*; do
            [ -d "$device" ] || continue

            local name_file="$device/name"
            [ -f "$name_file" ] || continue

            local name=$(cat "$name_file" 2>/dev/null)
            local name_lower=$(echo "$name" | tr '[:upper:]' '[:lower:]')

            local is_proximity=0
            local is_als=0

            if echo "$name_lower" | grep -qiE "$PROXIMITY_PATTERNS"; then
                is_proximity=1
            elif echo "$name_lower" | grep -qiE "$ALS_PATTERNS"; then
                is_als=1
            else
                continue
            fi

            found=$((found + 1))
            local sensor_type=""
            [ $is_proximity -eq 1 ] && sensor_type="PROXIMITY" || sensor_type="ALS"
            local enable_file="$device/enable"

            verify_sensor_device "$device" "$sensor_type" "$name" "$enable_file"
            echo ""
        done
    done

    if [ $found -eq 0 ]; then
        print_warn "No proximity or ALS sensors found in platform devices"
    fi
}

# Check vendor-specific paths
check_vendor_paths() {
    print_section "Checking Vendor-Specific Paths"

    local paths="
        /sys/devices/virtual/sensors/proximity_sensor/enable
        /sys/devices/virtual/sensors/light_sensor/enable
        /sys/class/sensors/proximity_sensor/enable
        /sys/class/sensors/light_sensor/enable
    "

    for enable_file in $paths; do
        [ -f "$enable_file" ] || continue

        local device_path=$(dirname "$enable_file")
        local name_file="$device_path/name"
        local name=""
        [ -f "$name_file" ] && name=$(cat "$name_file" 2>/dev/null)

        local sensor_type=""
        if echo "$device_path" | grep -qiE "proximity" || echo "$name" | grep -qiE "$PROXIMITY_PATTERNS"; then
            sensor_type="PROXIMITY"
        elif echo "$device_path" | grep -qiE "light|als|ambient" || echo "$name" | grep -qiE "$ALS_PATTERNS"; then
            sensor_type="ALS"
        else
            continue
        fi

        verify_sensor_device "$device_path" "$sensor_type" "$name" "$enable_file"
        echo ""
    done
}

# Check Android sensor HAL
check_sensor_hal() {
    print_section "Checking Android Sensor HAL"

    # Check if sensorservice is running
    local sensorservice_pid=$(pidof sensorservice 2>/dev/null)
    if [ -n "$sensorservice_pid" ]; then
        print_pass "sensorservice running (PID: $sensorservice_pid)"
    else
        print_warn "sensorservice not found"
    fi

    # Check sensor list via dumpsys (requires root)
    if [ "$(id -u)" = "0" ]; then
        print_info "Querying sensor list via dumpsys..."
        dumpsys sensorservice 2>/dev/null | head -100 | while IFS= read -r line; do
            if echo "$line" | grep -qiE "proximity|ambient|light"; then
                if echo "$line" | grep -qiE "enabled|active|reporting"; then
                    print_fail "HAL reports sensor active: $line"
                else
                    print_info "HAL sensor entry: $line"
                fi
            fi
        done
    else
        print_warn "Root required for dumpsys sensor check"
    fi
}

# Check module state
check_module_state() {
    print_section "Module State"

    if [ -f "$STATE_FILE" ]; then
        print_pass "State file exists: $STATE_FILE"
        echo "Contents:"
        cat "$STATE_FILE" | while IFS= read -r line; do
            echo "  $line"
        done
    else
        print_fail "State file NOT found: $STATE_FILE"
    fi

    if [ -f "$PERSIST_FILE" ]; then
        print_pass "Persist file exists: $PERSIST_FILE"
        cat "$PERSIST_FILE" | while IFS= read -r line; do
            echo "  $line"
        done
    else
        print_warn "Persist file not found: $PERSIST_FILE"
    fi

    # Check module installation
    if [ -f "$MODDIR/module.prop" ]; then
        print_pass "Module installed at: $MODDIR"
        grep -E "^(id|name|version|versionCode)=" "$MODDIR/module.prop" | while IFS= read -r line; do
            echo "  $line"
        done
    else
        print_fail "Module not found at: $MODDIR"
    fi
}

# Check service status
check_service_status() {
    print_section "Service Status"

    local monitor_pid_file="$STATE_DIR/monitor.pid"
    if [ -f "$monitor_pid_file" ]; then
        local pid=$(cat "$monitor_pid_file" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            print_pass "Monitor service running (PID: $pid)"
        else
            print_fail "Monitor service NOT running (stale PID: $pid)"
        fi
    else
        print_warn "Monitor PID file not found"
    fi

    # Check sensor service PIDs
    for svc in "sensorservice" "sensorhubservice" "vendor.sensorservice" "android.hardware.sensors@2.0-service"; do
        local pid_file="$STATE_DIR/${svc}.pid"
        if [ -f "$pid_file" ]; then
            local pid=$(cat "$pid_file" 2>/dev/null)
            local current=$(pidof "$svc" 2>/dev/null | awk '{print $1}')
            if [ -n "$current" ] && [ "$current" = "$pid" ]; then
                print_pass "$svc PID tracked: $pid"
            elif [ -n "$current" ]; then
                print_warn "$svc PID changed: tracked=$pid, current=$current"
            else
                print_warn "$svc not running (tracked PID: $pid)"
            fi
        fi
    done
}

# Test sensor data reading
test_sensor_reading() {
    print_section "Testing Sensor Data Reading"

    if [ "$(id -u)" != "0" ]; then
        print_warn "Root required for sensor data test"
        return
    fi

    # Try to read from IIO devices directly
    if [ -d "$IIO_SYSFS" ]; then
        for iio_dev in "$IIO_SYSFS"/iio:device*; do
            [ -d "$iio_dev" ] || continue
            local name_file="$iio_dev/name"
            [ -f "$name_file" ] || continue

            local name=$(cat "$name_file" 2>/dev/null | tr '[:upper:]' '[:lower:]')

            if echo "$name" | grep -qiE "$PROXIMITY_PATTERNS|$ALS_PATTERNS"; then
                print_info "Testing $name..."

                # Try to enable buffer temporarily and read
                local buffer_enable="$iio_dev/buffer/enable"
                local buffer_length="$iio_dev/buffer/length"
                local dev_file="/dev/$(basename "$iio_dev")"

                if [ -f "$buffer_enable" ] && [ -c "$dev_file" ]; then
                    # Save current state
                    local old_enable=$(cat "$buffer_enable" 2>/dev/null)
                    local old_length=$(cat "$buffer_length" 2>/dev/null)

                    # Try to enable
                    echo 1 > "$buffer_enable" 2>/dev/null
                    echo 10 > "$buffer_length" 2>/dev/null

                    # Try to read
                    local data=$(dd if="$dev_file" bs=64 count=1 2>/dev/null | od -x | head -5)
                    if [ -n "$data" ]; then
                        print_fail "  Sensor $name RETURNED DATA (NOT DISABLED):"
                        echo "  $data"
                    else
                        print_pass "  Sensor $name returned no data (disabled)"
                    fi

                    # Restore
                    echo "$old_enable" > "$buffer_enable" 2>/dev/null
                    echo "$old_length" > "$buffer_length" 2>/dev/null
                fi
            fi
        done
    fi
}

# Summary
print_summary() {
    print_section "Verification Summary"

    echo "Module: Sensor Nuke"
    echo "Version: 1.0.0"
    echo "Timestamp: $(date)"
    echo ""
    echo "Checks performed:"
    echo "  - IIO subsystem scan"
    echo "  - Platform sensor scan"
    echo "  - Vendor path check"
    echo "  - Android Sensor HAL check"
    echo "  - Module state verification"
    echo "  - Service status check"
    [ "$(id -u)" = "0" ] && echo "  - Direct sensor data read test"
    echo ""
    echo "Log file: $LOG_FILE"
    echo "State file: $STATE_FILE"
    echo ""
    print_info "If all target sensors show [PASS], they are successfully disabled."
    print_info "If any show [FAIL], run post-fs-data.sh manually or reboot."
}

# Main
main() {
    print_header
    check_root

    # Clear log
    > "$LOG_FILE"

    log "Starting sensor verification..."

    check_module_state
    echo ""

    scan_iio_devices
    echo ""

    scan_platform_sensors
    echo ""

    check_vendor_paths
    echo ""

    check_sensor_hal
    echo ""

    check_service_status
    echo ""

    test_sensor_reading
    echo ""

    print_summary

    log "Verification completed"
}

# Run main
main "$@"