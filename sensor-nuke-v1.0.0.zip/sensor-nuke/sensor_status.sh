#!/system/bin/sh
#
# Sensor Nuke - sensor_status.sh
# Quick status command for sensor state
# Can be called from terminal or integrated into shell
#

MODDIR="${0%/*}"
STATE_DIR="/data/adb/sensor-nuke"
STATE_FILE="$STATE_DIR/sensor_state.conf"
PERSIST_FILE="$STATE_DIR/persist.conf"
CONFIG_FILE="$MODDIR/config.sh"

# Load config
[ -f "$CONFIG_FILE" ] && . "$CONFIG_FILE"

PROXIMITY_PATTERNS="${PROXIMITY_PATTERNS:-proximity|prox}"
ALS_PATTERNS="${ALS_PATTERNS:-als|ambient.light|light.sensor}"
IIO_SYSFS="${IIO_SYSFS:-/sys/bus/iio/devices}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

usage() {
    echo "Usage: $0 [options]"
    echo "Options:"
    echo "  -h, --help       Show this help"
    echo "  -j, --json       Output JSON format"
    echo "  -q, --quiet      Only show summary"
    echo "  -v, --verbose    Show detailed info"
    exit 0
}

OUTPUT_FORMAT="text"
QUIET=0
VERBOSE=0

while [ $# -gt 0 ]; do
    case "$1" in
        -h|--help) usage ;;
        -j|--json) OUTPUT_FORMAT="json" ;;
        -q|--quiet) QUIET=1 ;;
        -v|--verbose) VERBOSE=1 ;;
        *) echo "Unknown option: $1"; usage ;;
    esac
    shift
done

# Check sensor state
check_sensor() {
    local sensor_type="$1"
    local pattern="$2"
    local found=0
    local disabled=0
    local details=""

    # Check IIO
    if [ -d "$IIO_SYSFS" ]; then
        for dev in "$IIO_SYSFS"/iio:device*; do
            [ -d "$dev" ] || continue
            local name=$(cat "$dev/name" 2>/dev/null | tr '[:upper:]' '[:lower:]')
            echo "$name" | grep -qiE "$pattern" || continue

            found=1
            local enable_file="$dev/enable"
            [ -f "$dev/buffer/enable" ] && enable_file="$dev/buffer/enable"

            if [ -f "$enable_file" ]; then
                local val=$(cat "$enable_file" 2>/dev/null)
                [ "$val" = "0" ] && disabled=1
                details="$details IIO:$dev=$val"
            fi

            # Check scan elements
            for scan in "$dev/scan_elements"/*_en; do
                [ -f "$scan" ] || continue
                local val=$(cat "$scan" 2>/dev/null)
                [ "$val" = "1" ] && disabled=0
                details="$details scan:$scan=$val"
            done
        done
    fi

    # Check platform
    for sysfs in /sys/bus/i2c/devices /sys/bus/spi/devices /sys/class/sensors /sys/class/hwmon /sys/devices/platform /sys/devices/virtual/sensors; do
        [ -d "$sysfs" ] || continue
        for dev in "$sysfs"/*; do
            [ -d "$dev" ] || continue
            local name=$(cat "$dev/name" 2>/dev/null | tr '[:upper:]' '[:lower:]')
            echo "$name" | grep -qiE "$pattern" || continue

            found=1
            local enable_file="$dev/enable"
            if [ -f "$enable_file" ]; then
                local val=$(cat "$enable_file" 2>/dev/null)
                [ "$val" = "0" ] && disabled=1
                details="$details platform:$dev=$val"
            fi
        done
    done

    echo "$found|$disabled|$details"
}

# Main check
prox_result=$(check_sensor "proximity" "$PROXIMITY_PATTERNS")
als_result=$(check_sensor "als" "$ALS_PATTERNS")

prox_found=$(echo "$prox_result" | cut -d'|' -f1)
prox_disabled=$(echo "$prox_result" | cut -d'|' -f2)
prox_details=$(echo "$prox_result" | cut -d'|' -f3-)

als_found=$(echo "$als_result" | cut -d'|' -f1)
als_disabled=$(echo "$als_result" | cut -d'|' -f2)
als_details=$(echo "$als_result" | cut -d'|' -f3-)

# Service status
monitor_running=0
if [ -f "$STATE_DIR/monitor.pid" ]; then
    pid=$(cat "$STATE_DIR/monitor.pid" 2>/dev/null)
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && monitor_running=1
fi

# Output
if [ "$OUTPUT_FORMAT" = "json" ]; then
    cat <<EOF
{
  "proximity": {
    "found": $prox_found,
    "disabled": $prox_disabled,
    "details": "$prox_details"
  },
  "als": {
    "found": $als_found,
    "disabled": $als_disabled,
    "details": "$als_details"
  },
  "service": {
    "monitor_running": $monitor_running
  },
  "module": {
    "installed": $([ -f "$MODDIR/module.prop" ] && echo 1 || echo 0),
    "state_file_exists": $([ -f "$STATE_FILE" ] && echo 1 || echo 0)
  }
}
EOF
    exit 0
fi

# Text output
if [ $QUIET -eq 0 ]; then
    echo "Sensor Nuke Status"
    echo "=================="
    echo ""
fi

# Proximity
if [ $prox_found -eq 1 ]; then
    if [ $prox_disabled -eq 1 ]; then
        echo -e "Proximity: ${GREEN}DISABLED${NC}"
    else
        echo -e "Proximity: ${RED}ENABLED${NC} (should be disabled!)"
    fi
else
    echo -e "Proximity: ${YELLOW}NOT FOUND${NC}"
fi

# ALS
if [ $als_found -eq 1 ]; then
    if [ $als_disabled -eq 1 ]; then
        echo -e "ALS:       ${GREEN}DISABLED${NC}"
    else
        echo -e "ALS:       ${RED}ENABLED${NC} (should be disabled!)"
    fi
else
    echo -e "ALS:       ${YELLOW}NOT FOUND${NC}"
fi

# Service
if [ $monitor_running -eq 1 ]; then
    echo -e "Service:   ${GREEN}RUNNING${NC}"
else
    echo -e "Service:   ${RED}STOPPED${NC}"
fi

if [ $QUIET -eq 0 ] && [ $VERBOSE -eq 1 ]; then
    echo ""
    echo "Details:"
    [ -n "$prox_details" ] && echo "  Proximity:$prox_details"
    [ -n "$als_details" ] && echo "  ALS:$als_details"
    echo ""
    echo "State file: $STATE_FILE"
    [ -f "$STATE_FILE" ] && cat "$STATE_FILE" | sed 's/^/  /'
fi

# Exit code: 0 = all disabled, 1 = some enabled, 2 = not found
if [ $prox_found -eq 1 ] && [ $als_found -eq 1 ]; then
    [ $prox_disabled -eq 1 ] && [ $als_disabled -eq 1 ] && exit 0 || exit 1
elif [ $prox_found -eq 1 ] && [ $prox_disabled -eq 1 ]; then
    exit 0
elif [ $als_found -eq 1 ] && [ $als_disabled -eq 1 ]; then
    exit 0
else
    exit 2
fi