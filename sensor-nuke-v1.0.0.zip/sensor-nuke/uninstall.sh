#!/system/bin/sh
#
# Sensor Nuke - uninstall.sh
# Restores original sensor state and cleans up module files
#

MODDIR="${0%/*}"
LOG_FILE="/data/local/tmp/sensor-nuke-uninstall.log"
STATE_DIR="/data/adb/sensor-nuke"
STATE_FILE="$STATE_DIR/sensor_state.conf"

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

log "=== Sensor Nuke uninstall.sh started ==="
log "Module directory: $MODDIR"
log "State directory: $STATE_DIR"

# Restore original sensor states from saved state
restore_sensors() {
    if [ ! -f "$STATE_FILE" ]; then
        log "No state file found at $STATE_FILE, nothing to restore"
        return 0
    fi

    log "Restoring sensors from state file: $STATE_FILE"

    local restored=0
    local failed=0

    # Parse ORIGINAL_* entries and restore
    while IFS= read -r line; do
        # Skip comments and non-original entries
        echo "$line" | grep -q "^ORIGINAL_" || continue

        # Parse: ORIGINAL_TYPE_PATH=value
        local var_part=$(echo "$line" | cut -d= -f1)
        local value=$(echo "$line" | cut -d= -f2-)

        # Extract type and path from variable name
        # ORIGINAL_PROXIMITY_sys_bus_iio_devices_iio_device0=0
        local type_path=$(echo "$var_part" | sed 's/^ORIGINAL_//')
        local sensor_type=$(echo "$type_path" | cut -d_ -f1)
        local path_part=$(echo "$type_path" | cut -d_ -f2-)

        # Reconstruct path
        local device_path="/$(echo "$path_part" | sed 's/_/\//g')"
        local enable_file="$device_path/enable"

        # For IIO devices, the enable file is different
        if echo "$device_path" | grep -q "/iio:device"; then
            enable_file="$device_path/buffer/enable"
        fi

        log "Restoring $sensor_type at $device_path to value: $value"

        if [ -f "$enable_file" ]; then
            echo "$value" > "$enable_file" 2>/dev/null
            if [ $? -eq 0 ]; then
                log "Successfully restored $sensor_type at $device_path"
                restored=$((restored + 1))
            else
                log "Failed to restore $sensor_type at $device_path"
                failed=$((failed + 1))
            fi
        else
            log "Enable file not found: $enable_file (may have been removed)"
            failed=$((failed + 1))
        fi

        # Also restore scan elements for IIO
        if echo "$device_path" | grep -q "/iio:device"; then
            local scan_dir="$device_path/scan_elements"
            if [ -d "$scan_dir" ]; then
                for scan_en in "$scan_dir"/*_en; do
                    [ -f "$scan_en" ] || continue
                    # Restore to 1 (enabled) by default
                    echo 1 > "$scan_en" 2>/dev/null
                done
            fi
        fi

        # Restore power control
        local power_control="$device_path/power/control"
        if [ -f "$power_control" ]; then
            local power_var="ORIGINAL_${sensor_type}_POWER_${path_part}"
            local power_value=$(grep "^$power_var=" "$STATE_FILE" | cut -d= -f2-)
            if [ -n "$power_value" ]; then
                echo "$power_value" > "$power_control" 2>/dev/null
                log "Restored power control for $sensor_type at $device_path to: $power_value"
            else
                # Default to 'on'
                echo "on" > "$power_control" 2>/dev/null
            fi
        fi

    done < "$STATE_FILE"

    log "Restoration complete: $restored restored, $failed failed"
}

# Re-enable sensors via common paths (fallback)
reenable_common_paths() {
    log "Re-enabling sensors via common paths as fallback..."

    local patterns="proximity als ambient light"
    local paths="
        /sys/bus/iio/devices/iio:device*/buffer/enable
        /sys/bus/i2c/devices/*/enable
        /sys/bus/spi/devices/*/enable
        /sys/class/sensors/*/enable
        /sys/devices/virtual/sensors/*/enable
        /sys/devices/platform/*/enable
    "

    for path in $paths; do
        for enable_file in $path; do
            [ -f "$enable_file" ] || continue
            local device_path=$(dirname "$enable_file")
            local name_file="$device_path/name"
            local name=""
            [ -f "$name_file" ] && name=$(cat "$name_file" 2>/dev/null | tr '[:upper:]' '[:lower:]')

            local is_target=0
            for pattern in $patterns; do
                if echo "$name" | grep -qi "$pattern" || echo "$device_path" | grep -qi "$pattern"; then
                    is_target=1
                    break
                fi
            done

            if [ $is_target -eq 1 ]; then
                log "Re-enabling sensor at $device_path ($name)"
                echo 1 > "$enable_file" 2>/dev/null
            fi
        done
    done
}

# Clean up state directory
cleanup_state() {
    log "Cleaning up state directory: $STATE_DIR"
    rm -rf "$STATE_DIR"
}

# Kill any running monitor process
kill_monitor() {
    local pid_file="$STATE_DIR/monitor.pid"
    if [ -f "$pid_file" ]; then
        local pid=$(cat "$pid_file" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            kill "$pid" 2>/dev/null
            log "Killed monitor process (PID: $pid)"
        fi
    fi
}

# Main uninstall logic
main() {
    log "Starting Sensor Nuke uninstallation..."

    # Kill monitor
    kill_monitor

    # Restore from saved state
    restore_sensors

    # Fallback re-enable
    reenable_common_paths

    # Clean up
    cleanup_state

    log "=== Sensor Nuke uninstall.sh completed ==="
    log "Sensors should now be restored to original state"
    log "Please reboot the device to ensure all changes take effect"
}

main "$@"