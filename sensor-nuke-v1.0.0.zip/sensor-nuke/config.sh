#!/system/bin/sh
#
# Sensor Nuke - config.sh
# Configuration file for sensor detection and disable behavior
# Copy this to config.sh.local to override without modifying the module
#

# =============================================================================
# SENSOR IDENTIFICATION PATTERNS
# =============================================================================
# Regex patterns (case-insensitive) to identify proximity and ALS sensors
# in device names. Modify these if your device uses different naming.

# Proximity sensor patterns
PROXIMITY_PATTERNS="proximity|prox"

# Ambient Light Sensor patterns
ALS_PATTERNS="als|ambient.light|light.sensor|ambient_light|light_sensor"

# =============================================================================
# SYSFS SEARCH PATHS
# =============================================================================
# Directories to scan for sensor devices. Add device-specific paths here.

# IIO (Industrial I/O) subsystem - most common for modern sensors
IIO_SYSFS="/sys/bus/iio/devices"

# Platform sensors and other common locations
SYSFS_SENSORS="
    /sys/bus/i2c/devices
    /sys/bus/spi/devices
    /sys/class/sensors
    /sys/class/hwmon
    /sys/devices/platform
    /sys/devices/virtual/sensors
    /sys/devices/soc0
    /sys/devices/platform/soc
"

# =============================================================================
# VENDOR-SPECIFIC PATHS
# =============================================================================
# Common vendor-specific sensor control paths. Enable/disable as needed.

# Enable vendor path scanning
ENABLE_VENDOR_PATHS=1

# Additional vendor paths (space-separated)
VENDOR_SENSOR_PATHS="
    /sys/devices/virtual/sensors/proximity_sensor/enable
    /sys/devices/virtual/sensors/light_sensor/enable
    /sys/class/sensors/proximity_sensor/enable
    /sys/class/sensors/light_sensor/enable
"

# =============================================================================
# DISABLE METHODS
# =============================================================================
# Methods to use for disabling sensors (1=enable, 0=disable)

# Method 1: Write 0 to enable file (most common)
DISABLE_VIA_ENABLE_FILE=1

# Method 2: Disable IIO buffer
DISABLE_VIA_IIO_BUFFER=1

# Method 3: Disable IIO scan elements
DISABLE_VIA_IIO_SCAN_ELEMENTS=1

# Method 4: Runtime PM suspend
DISABLE_VIA_RUNTIME_PM=1

# Method 5: Power control autosuspend
DISABLE_VIA_POWER_CONTROL=1

# =============================================================================
# PERSISTENCE SETTINGS
# =============================================================================

# Re-check interval in seconds (0 = disable periodic re-check)
PERSIST_CHECK_INTERVAL=300

# Monitor sensor service restarts
MONITOR_SENSOR_SERVICE=1

# Monitor vendor sensor services
MONITOR_VENDOR_SERVICES=1

# =============================================================================
# LOGGING SETTINGS
# =============================================================================

# Log level: 0=errors only, 1=warnings, 2=info, 3=debug
LOG_LEVEL=2

# Maximum log file size in KB (0 = unlimited)
MAX_LOG_SIZE=1024

# =============================================================================
# SAFETY SETTINGS
# =============================================================================

# Dry run mode - log what would be done but don't actually disable
DRY_RUN=0

# Skip sensors that don't match exact patterns (stricter matching)
STRICT_MATCHING=0

# Preserve sensors with these names even if they match patterns (whitelist)
SENSOR_WHITELIST=""

# =============================================================================
# DEVICE-SPECIFIC OVERRIDES
# =============================================================================
# Uncomment and modify for specific devices
# These are examples - replace with your device's actual paths

# Example: Pixel 6/7 (Google Tensor)
# PROXIMITY_PATTERNS="proximity|ltr553"
# ALS_PATTERNS="als|ambient|light|ltr553"
# IIO_SYSFS="/sys/bus/iio/devices"

# Example: Samsung Galaxy S series
# PROXIMITY_PATTERNS="proximity|stk3x1x|ap3212"
# ALS_PATTERNS="als|ambient|light|stk3x1x|ap3212"

# Example: OnePlus devices
# PROXIMITY_PATTERNS="proximity|cm36651|rpr0521"
# ALS_PATTERNS="als|ambient|light|cm36651|rpr0521"

# Example: Xiaomi devices
# PROXIMITY_PATTERNS="proximity|stk3x1x|ap3212|ltr553"
# ALS_PATTERNS="als|ambient|light|stk3x1x|ap3212|ltr553"

# =============================================================================
# ADVANCED: KERNEL MODULE PARAMETERS
# =============================================================================
# If your sensor drivers expose module parameters for disable,
# specify them here (module:parameter=value)

# Example:
# KERNEL_MODULE_PARAMS="
#     stk3x1x:enable=0
#     ltr553:enable=0
#     cm36651:enable=0
# "

KERNEL_MODULE_PARAMS=""

# =============================================================================
# ADVANCED: DEVICE TREE OVERRIDES (requires root and remount)
# =============================================================================
# WARNING: Modifying device tree is risky and not recommended for most users.
# Only enable if you know what you're doing and have a backup.

ENABLE_DT_OVERRIDES=0

# Paths to device tree overlays or dtb files (for reference only)
DT_OVERLAY_PATHS=""

# =============================================================================
# DO NOT EDIT BELOW THIS LINE - Module internals
# =============================================================================

# Internal version
CONFIG_VERSION=1